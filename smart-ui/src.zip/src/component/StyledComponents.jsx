import styled from 'styled-components';

export const ChatBotWrapper = styled.div`
    position: fixed;
    bottom: 6%;
    right: 2%;
    width: 18%;
    height: 60%;
    background-color: white;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    border-radius: 10px;
    border: 1px solid black;
    z-index: 1000;
    display: flex;
    flex-direction: column;
`;

export const ChatBotHeader = styled.div`
    display: flex;
    flex-direction: column;
    background-color: white;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    width: 100%;
    height: 15%;
    color: white;
    align-items: center;
    justify-content: space-between;
    box-sizing: border-box;
    & .header-one {
        width: 100%;
        height: 40%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        & button {
            border: none;
            background-color: transparent;
            cursor: pointer;
            font-size: 1.2em;
        }
        & .x-icon {
            color: black;
            cursor: pointer;
            margin-right: 5px;
        }
    }
    & .header-two {
        display: flex;
        justify-content: space-around;
        align-items: center;
        background-color: skyblue;
        color: black;
        width: 100%;
        height: 60%;
        & .header-two-one {
            display: flex;
            width: 100%;
            align-items: center;
            justify-content: center;
            & * {
                width: 100%;
                display: flex;
                justify-content: center;
            }
        }
        & .i-icon {
            position: absolute;
            color: white;
            right: 20%;
            width: 10%;
        }
        & .i-icon:hover {
            cursor: pointer;
            color: blue;
        }
    }
`;

export const ChatBotContent = styled.div`
    flex: 1;
    padding: 10px;
    overflow-y: auto;
    scrollbar-width: none; 
    -ms-overflow-style: none;
    
    &::-webkit-scrollbar { 
        display: none;  
    }
`;

export const ChatBotFooter = styled.div`
    height: 8%;
    border-top: 1px solid #ddd;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-around;
    & .input-area {
        display: flex;
        width: 75%;
        height: 50%;
        transition: width 0.3s ease;

        &.input-focused {
            width: 80%;
        }

        & .mic-icon {
            border: 1px solid #ccc;
            border-left: none;
            height: 90%;
            border-top-right-radius: 4px;
            border-bottom-right-radius: 4px;
            cursor: pointer;
            transition: opacity 0.3s ease;
        }

        &.input-focused .mic-icon {
            opacity: 0;
        }
    }
    & .arrow-icon{
        font-size: 20px;
        color: blue;
        transition: margin-left 0.3s ease;
    }
`;

export const ChatBotInput = styled.input`
    flex: 1;
    border: 1px solid #ccc;
    border-right: none;
    border-bottom-left-radius: 4px;
    border-top-left-radius: 4px;
    width: 100%;
`;

export const ChatBotButton = styled.button`
    border: none;
    border-radius: 4px;
    cursor: pointer;
`;

export const MessageBubble = styled.div`
    max-width: 100%;
    font-size: 13px;
    padding: 10px;
    border-radius: 10px;
    border: 1px solid black;
    position: relative;
    color: black;
    margin-bottom: 5px;

    ${({ sender }) =>
        sender === 'user'
            ? `
        margin-left: auto;
        margin-right: 0;
        text-align: left;
        border-bottom-right-radius: 0;
    `
            : `
        margin-left: 0;
        margin-right: auto;        
        text-align: left;
        border-bottom-left-radius: 0;
    `}
`;

export const MessageContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: ${({ sender }) => (sender === 'user' ? 'flex-end' : 'flex-start')};
    margin-bottom: 20px;
    
    .profile-container {
        display: flex;
        align-items: center;
        margin-bottom: 5px;
        ${({ sender }) =>
            sender === 'user'
                ? `
            flex-direction: row-reverse;
        `
                : `
            flex-direction: row;
        `}
    }

    .profile-image {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        margin: 0 10px;
    }

    .timestamp {
        font-size: 0.8em;
        color: gray;
        margin-top: 2px;
    }
`;
export const MessageButton = styled.button`
    margin: 5px;
    padding: 10px;
    border: none;
    border-radius: 10%;
    background-color: #007bff;
    color: white;
    cursor: pointer;
    
    &:hover {
        background-color: #0056b3;
    }
`;

export const ImagePreview = styled.img`
    max-width: 90%;
    height: auto;
    margin-top: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 5px;
`;
