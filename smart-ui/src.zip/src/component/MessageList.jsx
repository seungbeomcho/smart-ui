import { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleQuestion, faImage } from '@fortawesome/free-regular-svg-icons';
import { faXmark, faMicrophone, faCircleArrowUp } from '@fortawesome/free-solid-svg-icons';
import {
    ChatBotWrapper,
    ChatBotHeader,
    ChatBotContent,
    ChatBotFooter,
    ChatBotInput,
} from './StyledComponents';
import MessageList from './MessageList';

const ChatBot = ({ onClose, socket }) => {
    const [isGuideVisible, setIsGuideVisible] = useState(false);
    const [messages, setMessages] = useState([]);
    const [inputValue, setInputValue] = useState('');
    const [isInputFocused, setIsInputFocused] = useState(false);

    useEffect(() => {
        if (!socket) return;

        socket.on('connect', () => {
            socket.emit('join', 'User has connected');
        });

        socket.on('welcomeMessage', (message) => {
            const currentTime = new Date().toLocaleTimeString();
            setMessages((prevMessages) => [...prevMessages, { sender: 'bot', text: message, timestamp: currentTime }]);
        });

        socket.on('botResponse', (message) => {
            const currentTime = new Date().toLocaleTimeString();
            setMessages((prevMessages) => [...prevMessages, { sender: 'bot', text: message, timestamp: currentTime }]);
        });

        return () => {
            socket.off('connect');
            socket.off('welcomeMessage');
            socket.off('botResponse');
        };
    }, [socket]);

    const handleSendMessage = () => {
        if (inputValue.trim()) {
            const currentTime = new Date().toLocaleTimeString();
            const userMessage = { sender: 'user', text: inputValue, timestamp: currentTime };
            setMessages([...messages, userMessage]);
            socket.emit('userMessage', inputValue);
            setInputValue('');
        }
    };

    const showGuide = () => {
        setIsGuideVisible(true);
    };

    const hideGuide = () => {
        setIsGuideVisible(false);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            handleSendMessage();
        }
    };

    const handleImgClick = () => {
        setMessages((prevMessages) => [
            ...prevMessages,
            {
                sender: 'bot',
                text: 'Choose an option:',
                buttons: ['도면', '장비'],
                timestamp: new Date().toLocaleTimeString(),
            },
        ]);
    };

    const handleButtonClick = () => {
        document.getElementById('imageUpload').click();
    };

    const handleFileUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setMessages((prevMessages) => [
                    ...prevMessages,
                    {
                        sender: 'user',
                        image: reader.result,
                        timestamp: new Date().toLocaleTimeString(),
                    },
                ]);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleInputFocus = () => {
        setIsInputFocused(true);
    };

    const handleInputBlur = () => {
        setIsInputFocused(false);
    };

    return (
        <ChatBotWrapper>
            <ChatBotHeader>
                <div className='header-one'>
                    {isGuideVisible ? <button onClick={hideGuide}>&lt;</button> : <div />}
                    <FontAwesomeIcon className='x-icon' icon={faXmark} onClick={onClose} />
                </div>
                <div className='header-two'>
                    {!isGuideVisible ? (
                        <div className='header-two-one'>
                            <div>국토봇</div>
                            <FontAwesomeIcon className='i-icon' icon={faCircleQuestion} onClick={showGuide} />
                        </div>
                    ) : (
                        <div className='header-two-two'>사용 설명서</div>
                    )}
                </div>
            </ChatBotHeader>
            <ChatBotContent>
                {isGuideVisible ? (
                    <div>
                        <h2>사용 설명서</h2>
                        <p>여기에 사용 설명서 내용을 입력합니다...</p>
                    </div>
                ) : (
                    <MessageList messages={messages} onButtonClick={handleButtonClick} />
                )}
            </ChatBotContent>
            {!isGuideVisible && (
                <ChatBotFooter>
                    <FontAwesomeIcon icon={faImage} onClick={handleImgClick} />
                    <input type="file" style={{ display: 'none' }} id="imageUpload" onChange={handleFileUpload} />
                    <div className={`input-area ${isInputFocused ? 'input-focused' : ''}`}>
                        <ChatBotInput
                            type="text"
                            placeholder="질문을 입력해주세요..."
                            onKeyDown={handleKeyDown}
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            onFocus={handleInputFocus}
                            onBlur={handleInputBlur}
                        />
                        <FontAwesomeIcon className='mic-icon' icon={faMicrophone} />
                    </div>
                    <FontAwesomeIcon className='arrow-icon' onClick={handleSendMessage} icon={faCircleArrowUp} />
                </ChatBotFooter>
            )}
        </ChatBotWrapper>
    );
};

export default ChatBot;
