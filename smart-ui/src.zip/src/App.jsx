import React from 'react';
import Layout from './component/Layout';
import { ChatProvider } from './ChatContext';

function App() {
    return (
        <ChatProvider>
            <Layout />
        </ChatProvider>
    );
}

export default App;
